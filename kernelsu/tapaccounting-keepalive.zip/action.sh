#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="$MODDIR/config.env"
[ -f "$CONFIG" ] && . "$CONFIG"

PKG=${PKG:-com.taostudio.tapaccounting}
USER_ID=${USER_ID:-0}
MAIN_ACTIVITY=${MAIN_ACTIVITY:-com.taostudio.tapaccounting/.MainActivity}
SERVICE_COMPONENT=${SERVICE_COMPONENT:-com.taostudio.tapaccounting/.OverlayService}
SERVICE_ACTION=${SERVICE_ACTION:-ACTION_START_DOUBLE_TAP}
LOG=/data/adb/tapaccounting-keepalive.log

echo "$(date '+%Y-%m-%d %H:%M:%S') manual action triggered" >> "$LOG"
cmd deviceidle whitelist "+$PKG" >/dev/null 2>&1
dumpsys deviceidle whitelist "+$PKG" >/dev/null 2>&1
am set-inactive --user "$USER_ID" "$PKG" false >/dev/null 2>&1
cmd appops set --user "$USER_ID" "$PKG" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
cmd appops set --user "$USER_ID" "$PKG" RUN_IN_BACKGROUND allow >/dev/null 2>&1
cmd appops set --user "$USER_ID" "$PKG" START_FOREGROUND allow >/dev/null 2>&1
cmd appops set --user "$USER_ID" "$PKG" WAKE_LOCK allow >/dev/null 2>&1
cmd appops set --user "$USER_ID" "$PKG" SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1
cmd package set-stopped-state --user "$USER_ID" "$PKG" false >/dev/null 2>&1

am start-foreground-service --user "$USER_ID" -n "$SERVICE_COMPONENT" -a "$SERVICE_ACTION" >> "$LOG" 2>&1
sleep 2
if ! pidof "$PKG" >/dev/null 2>&1; then
  am start --user "$USER_ID" -n "$MAIN_ACTIVITY" --activity-clear-top --activity-single-top >> "$LOG" 2>&1
  sleep 3
  input keyevent KEYCODE_HOME >/dev/null 2>&1
fi

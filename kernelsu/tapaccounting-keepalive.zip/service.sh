#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="$MODDIR/config.env"
[ -f "$CONFIG" ] && . "$CONFIG"

PKG=${PKG:-com.taostudio.tapaccounting}
USER_ID=${USER_ID:-0}
MAIN_ACTIVITY=${MAIN_ACTIVITY:-com.taostudio.tapaccounting/.MainActivity}
SERVICE_COMPONENT=${SERVICE_COMPONENT:-com.taostudio.tapaccounting/.OverlayService}
SERVICE_ACTION=${SERVICE_ACTION:-ACTION_START_DOUBLE_TAP}
CHECK_INTERVAL=${CHECK_INTERVAL:-120}
ALLOW_ACTIVITY_FALLBACK=${ALLOW_ACTIVITY_FALLBACK:-1}
WHITELIST_ONLY=${WHITELIST_ONLY:-0}
LOG=/data/adb/tapaccounting-keepalive.log

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

run_quiet() {
  "$@" >/dev/null 2>&1
}

wait_boot_completed() {
  local boot
  boot="$(getprop sys.boot_completed 2>/dev/null)"
  while [ "$boot" != "1" ]; do
    sleep 5
    boot="$(getprop sys.boot_completed 2>/dev/null)"
  done
  sleep 20
}

package_exists() {
  pm path --user "$USER_ID" "$PKG" >/dev/null 2>&1
}

is_stopped() {
  dumpsys package "$PKG" 2>/dev/null | grep -m 1 "User $USER_ID:" | grep -q "stopped=true"
}

has_process() {
  pidof "$PKG" >/dev/null 2>&1
}

apply_allowlists() {
  run_quiet cmd deviceidle whitelist "+$PKG"
  run_quiet dumpsys deviceidle whitelist "+$PKG"

  run_quiet am set-inactive --user "$USER_ID" "$PKG" false

  run_quiet cmd appops set --user "$USER_ID" "$PKG" RUN_ANY_IN_BACKGROUND allow
  run_quiet cmd appops set --user "$USER_ID" "$PKG" RUN_IN_BACKGROUND allow
  run_quiet cmd appops set --user "$USER_ID" "$PKG" START_FOREGROUND allow
  run_quiet cmd appops set --user "$USER_ID" "$PKG" WAKE_LOCK allow
  run_quiet cmd appops set --user "$USER_ID" "$PKG" SYSTEM_ALERT_WINDOW allow
}

clear_stopped_state() {
  run_quiet cmd package set-stopped-state --user "$USER_ID" "$PKG" false
  run_quiet am force-stop --user "$USER_ID" __non_existing_package_name__
}

start_service_direct() {
  am start-foreground-service --user "$USER_ID" \
    -n "$SERVICE_COMPONENT" \
    -a "$SERVICE_ACTION" >> "$LOG" 2>&1
}

start_via_activity() {
  [ "$ALLOW_ACTIVITY_FALLBACK" = "1" ] || return 1
  am start --user "$USER_ID" \
    -n "$MAIN_ACTIVITY" \
    --activity-clear-top \
    --activity-single-top >> "$LOG" 2>&1 || return 1
  sleep 3
  run_quiet input keyevent KEYCODE_HOME
}

restore_app_if_needed() {
  [ "$WHITELIST_ONLY" = "1" ] && return 0

  if is_stopped; then
    log "$PKG is force-stopped; clearing stopped state"
    clear_stopped_state
  fi

  if has_process; then
    return 0
  fi

  log "$PKG has no process; attempting direct foreground service start"
  if start_service_direct; then
    sleep 5
    has_process && {
      log "$PKG restored by direct service start"
      return 0
    }
  fi

  log "direct service start did not restore $PKG; using activity fallback"
  if start_via_activity; then
    sleep 5
    has_process && log "$PKG restored by activity fallback"
  fi
}

main_loop() {
  wait_boot_completed
  log "TapAccounting KeepAlive started for $PKG"

  while true; do
    if package_exists; then
      apply_allowlists
      restore_app_if_needed
    else
      log "$PKG is not installed for user $USER_ID"
    fi
    sleep "$CHECK_INTERVAL"
  done
}

main_loop &

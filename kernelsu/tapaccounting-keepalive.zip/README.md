# TapAccounting KeepAlive KernelSU Module

This is a KernelSU/Magisk-compatible module for a rooted personal device.

It does three things:

1. Adds `com.taostudio.tapaccounting` to Android device-idle whitelist.
2. Allows relevant appops such as foreground service, background run, wake lock, and overlay.
3. Watches for OEM force-stop/stopped state and tries to restore the app.

Important notes:

- It does not disable `com.oplus.battery`.
- It does not hide the app from the system.
- `OverlayService` is `exported=false`, so direct service start may be rejected. When that happens, the module briefly launches `MainActivity` and sends Home so the app can start its own foreground service.
- To avoid this UI fallback later, add a small exported root-only receiver in the app and let this module broadcast to it.

Log path:

```text
/data/adb/tapaccounting-keepalive.log
```

Config path after install:

```text
/data/adb/modules/tapaccounting_keepalive/config.env
```

Useful switches:

```text
CHECK_INTERVAL=120
ALLOW_ACTIVITY_FALLBACK=1
WHITELIST_ONLY=0
```

Set `WHITELIST_ONLY=1` if you only want allowlists and never want the module to launch the app.
